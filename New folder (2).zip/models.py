from datetime import datetime
import uuid
from sqlalchemy.dialects.postgresql import ARRAY, ENUM
from app import db

def generate_cuid():
    # Simple replacement for cuid for python
    return str(uuid.uuid4()).replace("-", "")

delivery_method_enum = ENUM('HOME_DELIVERY', 'STORE_PICKUP', name='delivery_method')
order_status_enum = ENUM('PENDING', 'PROCESSING', 'SHIPPED', 'DELIVERED', name='order_status')
menu_item_type_enum = ENUM('INTERNAL', 'PAGE', 'EXTERNAL', name='menu_item_type')

page_products = db.Table('_PageProducts',
    db.Column('A', db.String, db.ForeignKey('Page.id', ondelete='CASCADE'), primary_key=True),
    db.Column('B', db.String, db.ForeignKey('Product.id', ondelete='CASCADE'), primary_key=True)
)

class User(db.Model):
    __tablename__ = 'User'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    name = db.Column(db.String, nullable=True)
    email = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String, default="ADMIN", nullable=False)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Category(db.Model):
    __tablename__ = 'Category'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    name = db.Column(db.String, unique=True, nullable=False)
    slug = db.Column(db.String, unique=True, nullable=False)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    products = db.relationship('Product', backref='category', lazy=True)

class Product(db.Model):
    __tablename__ = 'Product'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    name = db.Column(db.String, nullable=False)
    slug = db.Column(db.String, unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Integer, default=0, nullable=False)
    images = db.Column(ARRAY(db.String), default=list)
    videos = db.Column(ARRAY(db.String), default=list)
    featured = db.Column(db.Boolean, default=False)
    best_seller = db.Column('bestSeller', db.Boolean, default=False)
    is_new = db.Column('isNew', db.Boolean, default=False)
    category_id = db.Column('categoryId', db.String, db.ForeignKey('Category.id'), nullable=False, index=True)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    variants = db.relationship('ProductVariant', backref='product', lazy=True, cascade="all, delete-orphan")
    pages = db.relationship('Page', secondary=page_products, back_populates='products')
    order_items = db.relationship('OrderItem', back_populates='product_rel')

class ProductVariant(db.Model):
    __tablename__ = 'ProductVariant'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    product_id = db.Column('productId', db.String, db.ForeignKey('Product.id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Integer, default=0, nullable=False)
    is_default = db.Column('isDefault', db.Boolean, default=False)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    order_items = db.relationship('OrderItem', back_populates='variant_rel')

class Page(db.Model):
    __tablename__ = 'Page'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    title = db.Column(db.String, nullable=False)
    slug = db.Column(db.String, unique=True, nullable=False, index=True)
    excerpt = db.Column(db.String, nullable=True)
    content = db.Column(db.Text, nullable=False)
    hero_image = db.Column('heroImage', db.String, nullable=True)
    published = db.Column(db.Boolean, default=True, index=True)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    products = db.relationship('Product', secondary=page_products, back_populates='pages')
    menu_items = db.relationship('MenuItem', backref='page_rel', lazy=True)

class MenuItem(db.Model):
    __tablename__ = 'MenuItem'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    label = db.Column(db.String, nullable=False)
    href = db.Column(db.String, nullable=True)
    type = db.Column(menu_item_type_enum, default='INTERNAL', nullable=False)
    position = db.Column(db.Integer, default=0, index=True)
    visible = db.Column(db.Boolean, default=True, index=True)
    page_id = db.Column('pageId', db.String, db.ForeignKey('Page.id', ondelete='SET NULL'), nullable=True, index=True)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Order(db.Model):
    __tablename__ = 'Order'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    order_number = db.Column('orderNumber', db.String, unique=True, nullable=False)
    customer_name = db.Column('customerName', db.String, nullable=False)
    customer_email = db.Column('customerEmail', db.String, nullable=False, index=True)
    customer_phone = db.Column('customerPhone', db.String, nullable=False)
    delivery_method = db.Column('deliveryMethod', delivery_method_enum, nullable=False)
    address = db.Column(db.String, nullable=True)
    city = db.Column(db.String, nullable=True)
    zip = db.Column(db.String, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    subtotal = db.Column(db.Numeric(10, 2), default=0)
    delivery_fee = db.Column('deliveryFee', db.Numeric(10, 2), default=0)
    total = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(order_status_enum, default='PENDING', index=True)
    created_at = db.Column('createdAt', db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column('updatedAt', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    items = db.relationship('OrderItem', back_populates='order_rel', cascade="all, delete-orphan")

class OrderItem(db.Model):
    __tablename__ = 'OrderItem'
    id = db.Column(db.String, primary_key=True, default=generate_cuid)
    order_id = db.Column('orderId', db.String, db.ForeignKey('Order.id', ondelete='CASCADE'), nullable=False, index=True)
    product_id = db.Column('productId', db.String, db.ForeignKey('Product.id', ondelete='SET NULL'), nullable=True, index=True)
    product_variant_id = db.Column('productVariantId', db.String, db.ForeignKey('ProductVariant.id', ondelete='SET NULL'), nullable=True, index=True)
    product_name = db.Column('productName', db.String, nullable=False)
    variant_name = db.Column('variantName', db.String, nullable=True)
    product_image = db.Column('productImage', db.String, nullable=True)
    product_price = db.Column('productPrice', db.Numeric(10, 2), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    
    order_rel = db.relationship('Order', back_populates='items')
    product_rel = db.relationship('Product', back_populates='order_items')
    variant_rel = db.relationship('ProductVariant', back_populates='order_items')
