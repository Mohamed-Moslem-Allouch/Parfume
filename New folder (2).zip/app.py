import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from dotenv import load_dotenv

load_dotenv()

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    
    # Load from .env or environment
    database_url = os.environ.get('DATABASE_URL')
    if database_url:
        if "?" in database_url:
            database_url = database_url.split("?")[0]
            
        if database_url.startswith("postgres://"):
            database_url = database_url.replace("postgres://", "postgresql+pg8000://", 1)
        elif database_url.startswith("postgresql://"):
            database_url = database_url.replace("postgresql://", "postgresql+pg8000://", 1)
        
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url or 'sqlite:///local.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    migrate.init_app(app, db)
    
    with app.app_context():
        import models
        # Create tables if they don't exist since migrations had schema issues
        db.create_all()
    
    @app.route('/')
    def home():
        from models import Product
        from flask import render_template
        featured = Product.query.filter_by(featured=True).limit(8).all()
        return render_template('home.html', featured_products=featured)
        
    @app.route('/shop')
    def shop():
        from models import Product, Category
        from flask import render_template, request
        
        category_slug = request.args.get('category')
        categories = Category.query.all()
        
        query = Product.query
        if category_slug:
            category = Category.query.filter_by(slug=category_slug).first()
            if category:
                query = query.filter_by(category_id=category.id)
                
        products = query.all()
        return render_template('shop.html', products=products, categories=categories, active_category=category_slug)
        
    @app.route('/products/<slug>')
    def product_detail(slug):
        from models import Product
        from flask import render_template, abort
        product = Product.query.filter_by(slug=slug).first()
        if not product:
            abort(404)
        return render_template('product.html', product=product)

    @app.route('/cart')
    def cart():
        from flask import render_template
        return render_template('cart.html')
        
    @app.route('/api/cart-details', methods=['POST'])
    def cart_details():
        from models import Product
        from flask import request, jsonify
        data = request.json
        if not data or 'items' not in data:
            return jsonify({'items': []})
            
        cart_items = []
        for item in data['items']:
            product = Product.query.filter_by(id=item['productId']).first()
            if product:
                cart_items.append({
                    'id': product.id,
                    'name': product.name,
                    'price': float(product.price),
                    'quantity': item['quantity'],
                    'image': product.images[0] if product.images else None
                })
                
        return jsonify({'items': cart_items})
    
    return app
