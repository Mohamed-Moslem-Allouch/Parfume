import Link from "next/link";
import { AdminShell } from "@/components/admin/admin-shell";
import { OrderStatusFilter } from "@/components/admin/order-status-filter";
import { StatusSelect } from "@/components/admin/status-select";
import { formatCurrency, formatDate, toNumber } from "@/lib/format";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

type OrdersPageProps = {
  searchParams: {
    status?: string;
  };
};

export default async function AdminOrdersPage({ searchParams }: OrdersPageProps) {
  await requireAdmin();
  const status = searchParams.status;
  const validStatus = status && ["PENDING", "PROCESSING", "SHIPPED", "DELIVERED"].includes(status) ? status : undefined;

  const orders = await prisma.order.findMany({
    where: validStatus ? { status: validStatus as "PENDING" | "PROCESSING" | "SHIPPED" | "DELIVERED" } : undefined,
    orderBy: { createdAt: "desc" },
    include: { items: true }
  });

  return (
    <AdminShell>
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.24em] text-gold">Orders</p>
          <h1 className="mt-3 font-heading text-4xl text-mist">Order management</h1>
        </div>
        <OrderStatusFilter value={validStatus || "ALL"} />
      </div>
      <div className="overflow-hidden rounded-md border border-white/10 bg-obsidian">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[960px] border-collapse">
            <thead className="text-xs uppercase tracking-[0.18em] text-muted">
              <tr>
                <th className="table-cell">Order</th>
                <th className="table-cell">Date</th>
                <th className="table-cell">Customer</th>
                <th className="table-cell">Delivery</th>
                <th className="table-cell">Status</th>
                <th className="table-cell text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td className="table-cell">
                    <Link href={`/admin/orders/${order.id}`} className="font-medium text-gold">
                      {order.orderNumber}
                    </Link>
                  </td>
                  <td className="table-cell text-muted">{formatDate(order.createdAt)}</td>
                  <td className="table-cell">
                    <div className="text-mist">{order.customerName}</div>
                    <div className="text-xs text-muted">{order.customerEmail}</div>
                  </td>
                  <td className="table-cell text-muted">{order.deliveryMethod === "HOME_DELIVERY" ? "Home delivery" : "Store pickup"}</td>
                  <td className="table-cell">
                    <StatusSelect orderId={order.id} value={order.status} />
                  </td>
                  <td className="table-cell text-right font-bold text-gold">{formatCurrency(toNumber(order.total))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminShell>
  );
}
