import Link from "next/link";
import { ArrowRight, FileText, FolderTree, Menu as MenuIcon, Package, ReceiptText, Sparkles, TrendingUp } from "lucide-react";
import { AdminShell } from "@/components/admin/admin-shell";
import { formatCurrency, formatDate, toNumber } from "@/lib/format";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  await requireAdmin();

  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  const [totalOrders, totalProducts, totalCategories, totalPages, newOrdersWeek, recentOrders, totals, statusCounts] = await Promise.all([
    prisma.order.count(),
    prisma.product.count(),
    prisma.category.count(),
    prisma.page.count(),
    prisma.order.count({ where: { createdAt: { gte: weekAgo } } }),
    prisma.order.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      include: { items: true }
    }),
    prisma.order.findMany({
      select: { total: true }
    }),
    prisma.order.groupBy({
      by: ["status"],
      _count: { status: true }
    })
  ]);

  const revenue = totals.reduce((sum, order) => sum + toNumber(order.total), 0);
  const averageOrder = totalOrders ? revenue / totalOrders : 0;

  return (
    <AdminShell>
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.24em] text-gold">Admin dashboard</p>
          <h1 className="mt-3 font-heading text-4xl text-mist">Store overview</h1>
        </div>
        <Link href="/admin/products/new" className="btn-primary w-fit">
          Add Product
        </Link>
      </div>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Total orders", value: totalOrders, icon: ReceiptText },
          { label: "Products", value: totalProducts, icon: Package },
          { label: "New this week", value: newOrdersWeek, icon: Sparkles },
          { label: "Revenue", value: formatCurrency(revenue), icon: TrendingUp }
        ].map((card) => (
          <div key={card.label} className="rounded-md border border-white/10 bg-obsidian p-5">
            <card.icon className="h-5 w-5 text-gold" />
            <p className="mt-4 text-sm text-muted">{card.label}</p>
            <p className="mt-2 text-2xl font-bold text-mist">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1fr]">
        <section className="rounded-md border border-white/10 bg-obsidian p-5">
          <h2 className="font-heading text-2xl text-mist">Order status</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-4">
            {["PENDING", "PROCESSING", "SHIPPED", "DELIVERED"].map((status) => {
              const count = statusCounts.find((item) => item.status === status)?._count.status || 0;

              return (
                <div key={status} className="rounded-md border border-white/10 bg-midnight p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-muted">{status.replace("_", " ")}</p>
                  <p className="mt-2 text-2xl font-bold text-gold">{count}</p>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-md border border-white/10 bg-obsidian p-5">
          <h2 className="font-heading text-2xl text-mist">Catalog controls</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {[
              { href: "/admin/products", label: "Products", value: totalProducts, icon: Package },
              { href: "/admin/categories", label: "Categories", value: totalCategories, icon: FolderTree },
              { href: "/admin/pages", label: "Pages", value: totalPages, icon: FileText },
              { href: "/admin/menu", label: "Menu", value: "Edit", icon: MenuIcon }
            ].map((item) => (
              <Link key={item.href} href={item.href} className="rounded-md border border-white/10 bg-midnight p-4 transition hover:border-gold/50">
                <item.icon className="h-5 w-5 text-gold" />
                <p className="mt-3 text-sm text-muted">{item.label}</p>
                <p className="mt-1 text-2xl font-bold text-mist">{item.value}</p>
              </Link>
            ))}
          </div>
          <p className="mt-5 text-sm text-muted">Average order value: <span className="font-bold text-gold">{formatCurrency(averageOrder)}</span></p>
        </section>
      </div>

      <section className="mt-5 rounded-md border border-white/10 bg-obsidian">
        <div className="flex items-center justify-between border-b border-white/10 p-5">
          <h2 className="font-heading text-2xl text-mist">Recent orders</h2>
          <Link href="/admin/orders" className="inline-flex items-center gap-2 text-sm font-medium text-gold">
            View all
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse">
            <thead className="text-xs uppercase tracking-[0.18em] text-muted">
              <tr>
                <th className="table-cell">Order</th>
                <th className="table-cell">Customer</th>
                <th className="table-cell">Date</th>
                <th className="table-cell">Status</th>
                <th className="table-cell text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order) => (
                <tr key={order.id} className="text-mist">
                  <td className="table-cell">
                    <Link href={`/admin/orders/${order.id}`} className="font-medium text-gold">
                      {order.orderNumber}
                    </Link>
                  </td>
                  <td className="table-cell">{order.customerName}</td>
                  <td className="table-cell text-muted">{formatDate(order.createdAt)}</td>
                  <td className="table-cell">{order.status.replace("_", " ")}</td>
                  <td className="table-cell text-right font-bold text-gold">{formatCurrency(toNumber(order.total))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </AdminShell>
  );
}
