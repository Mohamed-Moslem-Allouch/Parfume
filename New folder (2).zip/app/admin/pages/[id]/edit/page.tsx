import Link from "next/link";
import { notFound } from "next/navigation";
import { AdminShell } from "@/components/admin/admin-shell";
import { PageForm } from "@/components/admin/page-form";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

type EditPageProps = {
  params: {
    id: string;
  };
};

export default async function EditPagePage({ params }: EditPageProps) {
  await requireAdmin();

  const [page, products] = await Promise.all([
    prisma.page.findUnique({
      where: { id: params.id },
      include: {
        products: {
          select: { id: true }
        },
        menuItems: {
          select: { id: true, label: true, visible: true },
          orderBy: { position: "asc" }
        }
      }
    }),
    prisma.product.findMany({
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        images: true,
        category: {
          select: { name: true }
        },
        pages: {
          select: { id: true, title: true, slug: true },
          orderBy: { title: "asc" }
        }
      }
    })
  ]);

  if (!page) {
    notFound();
  }

  return (
    <AdminShell>
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.24em] text-gold">Custom pages</p>
          <h1 className="mt-3 font-heading text-4xl text-mist">Edit {page.title}</h1>
        </div>
        <Link href="/admin/pages" className="btn-secondary w-fit">
          Back to Pages
        </Link>
      </div>
      <PageForm products={products} page={page} />
    </AdminShell>
  );
}
