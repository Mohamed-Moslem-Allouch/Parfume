import Link from "next/link";
import { AdminShell } from "@/components/admin/admin-shell";
import { PageForm } from "@/components/admin/page-form";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export default async function NewPagePage() {
  await requireAdmin();

  const products = await prisma.product.findMany({
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      images: true,
      category: {
        select: { name: true }
      },
      pages: {
        select: { id: true, title: true, slug: true },
        orderBy: { title: "asc" }
      }
    }
  });

  return (
    <AdminShell>
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.24em] text-gold">Custom pages</p>
          <h1 className="mt-3 font-heading text-4xl text-mist">Add page</h1>
        </div>
        <Link href="/admin/pages" className="btn-secondary w-fit">
          Back to Pages
        </Link>
      </div>
      <PageForm products={products} />
    </AdminShell>
  );
}
