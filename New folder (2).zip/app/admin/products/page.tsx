import Link from "next/link";
import { Plus } from "lucide-react";
import { AdminShell } from "@/components/admin/admin-shell";
import { ProductManagementTable } from "@/components/admin/product-management-table";
import { toNumber } from "@/lib/format";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  await requireAdmin();

  const [products, categories, pages] = await Promise.all([
    prisma.product.findMany({
      include: {
        category: true,
        variants: {
          select: { id: true, name: true, stock: true },
          orderBy: { createdAt: "asc" }
        },
        pages: {
          select: { id: true, title: true, slug: true },
          orderBy: { title: "asc" }
        }
      },
      orderBy: { updatedAt: "desc" }
    }),
    prisma.category.findMany({
      select: { id: true, name: true, slug: true },
      orderBy: { name: "asc" }
    }),
    prisma.page.findMany({
      select: { id: true, title: true, slug: true },
      orderBy: { title: "asc" }
    })
  ]);

  const productRows = products.map((product) => ({
    id: product.id,
    name: product.name,
    slug: product.slug,
    images: product.images,
    price: toNumber(product.price),
    stock: product.stock,
    featured: product.featured,
    updatedAt: product.updatedAt.toISOString(),
    category: {
      id: product.category.id,
      name: product.category.name,
      slug: product.category.slug
    },
    variants: product.variants,
    pages: product.pages
  }));

  return (
    <AdminShell>
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm uppercase tracking-[0.24em] text-gold">Products</p>
          <h1 className="mt-3 font-heading text-4xl text-mist">Product management</h1>
        </div>
        <Link href="/admin/products/new" className="btn-primary w-fit">
          <Plus className="h-4 w-4" />
          Add New Product
        </Link>
      </div>
      <ProductManagementTable products={productRows} categories={categories} pages={pages} />
    </AdminShell>
  );
}
