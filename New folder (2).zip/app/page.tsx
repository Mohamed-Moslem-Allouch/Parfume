import Link from "next/link";
import { ArrowRight, Droplets, Gem, ShieldCheck, Sparkles, Truck } from "lucide-react";
import { HeroParticles } from "@/components/hero-particles";
import { ProductCard } from "@/components/product-card";
import { Reveal } from "@/components/reveal";
import { StoreMap } from "@/components/store-map";
import { serializeProduct } from "@/lib/mappers";
import { prisma } from "@/lib/prisma";
import { storeConfig } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, newArrivals, bestSellers, categories] = await Promise.all([
    prisma.product.findMany({
      where: { featured: true },
      include: { category: true, variants: true, pages: { select: { id: true, title: true, slug: true } } },
      orderBy: { createdAt: "desc" },
      take: 5
    }),
    prisma.product.findMany({
      include: { category: true, variants: true, pages: { select: { id: true, title: true, slug: true } } },
      orderBy: { createdAt: "desc" },
      take: 5
    }),
    prisma.product.findMany({
      where: { bestSeller: true },
      include: { category: true, variants: true, pages: { select: { id: true, title: true, slug: true } } },
      orderBy: { createdAt: "desc" },
      take: 5
    }),
    prisma.category.findMany({
      include: { _count: { select: { products: true } } },
      orderBy: { name: "asc" }
    })
  ]);

  const featuredProducts = featured.map(serializeProduct);
  const newProducts = newArrivals.map(serializeProduct);
  const bestSellerProducts = bestSellers.map(serializeProduct);

  const categoryIcons: Record<string, typeof Sparkles> = {
    default: Gem
  };

  return (
    <>
      {/* Hero */}
      <section className="relative isolate min-h-[calc(100vh-5rem)] overflow-hidden">
        <HeroParticles />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.12),transparent_32rem)]" />
        <div className="section-shell relative z-10 flex min-h-[calc(100vh-5rem)] items-center py-16">
          <div className="max-w-3xl">
            <Reveal>
              <p className="mb-5 inline-flex rounded-lg border border-gold/30 bg-gold/10 px-4 py-2 text-sm font-medium text-gold">
                ✨ Beauty & Fragrance Store
              </p>
              <h1 className="font-heading text-4xl font-bold leading-tight text-mist sm:text-5xl md:text-7xl">
                Discover the scent that leaves a <span className="gold-text">golden memory</span>.
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-8 text-muted md:text-lg">
                Shop refined perfumes, body care, oils, shampoo, crème, and premium beauty products with store pickup or home delivery.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/shop" className="btn-primary">
                  Shop Now
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link href="#featured" className="btn-secondary">
                  Featured Products
                </Link>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="section-shell py-14 md:py-20">
          <Reveal>
            <p className="text-sm uppercase tracking-[0.24em] text-gold">Browse by type</p>
            <h2 className="mt-3 font-heading text-3xl text-mist md:text-5xl">Shop by Category</h2>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4 xl:grid-cols-5">
            {categories.map((cat, index) => {
              const Icon = categoryIcons[cat.slug] || categoryIcons.default;
              return (
                <Reveal key={cat.id} delay={index * 0.06}>
                  <Link
                    href={`/shop?category=${cat.slug}`}
                    className="group flex flex-col items-center gap-3 rounded-lg border border-white/10 bg-obsidian p-5 text-center transition hover:border-gold/50 hover:shadow-gold sm:p-6"
                  >
                    <div className="grid h-12 w-12 place-items-center rounded-lg bg-gold/10 text-gold transition group-hover:bg-gold/20 group-hover:scale-110">
                      <Icon className="h-6 w-6" />
                    </div>
                    <span className="font-heading text-sm text-mist group-hover:text-gold sm:text-base">{cat.name}</span>
                    <span className="text-xs text-muted">{cat._count.products} products</span>
                  </Link>
                </Reveal>
              );
            })}
          </div>
        </section>
      )}

      {/* Featured */}
      <section id="featured" className="section-shell py-14 md:py-20">
        <Reveal>
          <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="text-sm uppercase tracking-[0.24em] text-gold">Featured products</p>
              <h2 className="mt-3 font-heading text-3xl text-mist md:text-5xl">Bestsellers with a quiet glow</h2>
            </div>
            <Link href="/shop" className="btn-secondary w-fit">
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4 xl:grid-cols-5">
          {featuredProducts.map((product, index) => (
            <Reveal key={product.id} delay={index * 0.06}>
              <ProductCard product={product} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      {newProducts.length > 0 && (
        <section className="border-y border-white/10 bg-obsidian/40 py-14 md:py-20">
          <div className="section-shell">
            <Reveal>
              <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
                <div>
                  <p className="text-sm uppercase tracking-[0.24em] text-gold">Just arrived</p>
                  <h2 className="mt-3 font-heading text-3xl text-mist md:text-5xl">New Arrivals</h2>
                </div>
                <Link href="/shop" className="btn-secondary w-fit">
                  View All
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </Reveal>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4 xl:grid-cols-5">
              {newProducts.map((product, index) => (
                <Reveal key={product.id} delay={index * 0.06}>
                  <ProductCard product={product} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Best Sellers */}
      {bestSellerProducts.length > 0 && (
        <section className="section-shell py-14 md:py-20">
          <Reveal>
            <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <p className="text-sm uppercase tracking-[0.24em] text-gold">Most loved</p>
                <h2 className="mt-3 font-heading text-3xl text-mist md:text-5xl">Best Sellers</h2>
              </div>
              <Link href="/shop" className="btn-secondary w-fit">
                View All
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4 xl:grid-cols-5">
            {bestSellerProducts.map((product, index) => (
              <Reveal key={product.id} delay={index * 0.06}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </section>
      )}

      {/* Why Choose Us */}
      <section className="border-y border-white/10 bg-obsidian/70 py-14 md:py-20">
        <div className="section-shell">
          <Reveal>
            <p className="text-sm uppercase tracking-[0.24em] text-gold">Why choose us</p>
            <h2 className="mt-3 max-w-3xl font-heading text-3xl text-mist md:text-5xl">
              Carefully selected products, handled with boutique-level care.
            </h2>
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 md:grid-cols-4">
            {[
              { icon: Sparkles, title: "Curated selection", text: "Each product is selected for quality, character, and lasting appeal." },
              { icon: Droplets, title: "Premium quality", text: "From perfumes to skincare, we source only the finest ingredients." },
              { icon: ShieldCheck, title: "Secure platform", text: "Your orders and data are managed with care and protection." },
              { icon: Truck, title: "Flexible delivery", text: "Choose home delivery or store pickup during checkout." }
            ].map((item, index) => (
              <Reveal key={item.title} delay={index * 0.06}>
                <div className="h-full rounded-lg border border-white/10 bg-midnight p-5 transition hover:border-gold/50">
                  <item.icon className="h-6 w-6 text-gold" />
                  <h3 className="mt-4 font-heading text-xl text-mist">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted">{item.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Store Location + Map */}
      <section className="section-shell py-14 md:py-20">
        <Reveal>
          <div className="grid gap-6 overflow-hidden rounded-lg border border-gold/25 bg-obsidian md:grid-cols-[1fr_1.1fr]">
            <div className="p-6 md:p-8">
              <p className="text-sm uppercase tracking-[0.24em] text-gold">Store location</p>
              <h2 className="mt-3 font-heading text-3xl text-mist md:text-4xl">Visit our store</h2>
              <p className="mt-4 max-w-xl text-muted">{storeConfig.address}</p>
              <p className="mt-2 text-sm text-muted">{storeConfig.phone}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/checkout" className="btn-primary">
                  Plan Pickup
                </Link>
                <Link href="/shop" className="btn-secondary">
                  Browse First
                </Link>
              </div>
            </div>
            <div className="min-h-[280px] md:min-h-[340px]">
              <StoreMap />
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
