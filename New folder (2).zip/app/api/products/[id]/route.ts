import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { serializeProduct } from "@/lib/mappers";
import { prisma } from "@/lib/prisma";
import { createUniqueProductSlug } from "@/lib/products";
import { productSchema } from "@/lib/validators";

type Params = {
  params: {
    id: string;
  };
};

export async function GET(_request: Request, { params }: Params) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      category: true,
      variants: true,
      pages: {
        select: { id: true, title: true, slug: true }
      }
    }
  });

  if (!product) {
    return NextResponse.json({ message: "Product not found" }, { status: 404 });
  }

  return NextResponse.json({ product: serializeProduct(product) });
}

export async function PUT(request: Request, { params }: Params) {
  const session = await getServerSession(authOptions);

  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = productSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid product data", errors: parsed.error.flatten() }, { status: 400 });
  }

  const existing = await prisma.product.findUnique({
    where: { id: params.id },
    select: { id: true }
  });

  if (!existing) {
    return NextResponse.json({ message: "Product not found" }, { status: 404 });
  }

  const slug = await createUniqueProductSlug(parsed.data.name, params.id);

  const defaultIndex = Math.max(0, parsed.data.variants.findIndex((variant) => variant.isDefault));
  const price = Math.min(...parsed.data.variants.map((variant) => variant.price));
  const stock = parsed.data.variants.reduce((sum, variant) => sum + variant.stock, 0);

  const product = await prisma.product.update({
    where: { id: params.id },
    data: {
      name: parsed.data.name,
      description: parsed.data.description,
      categoryId: parsed.data.categoryId,
      images: parsed.data.images,
      videos: parsed.data.videos,
      featured: parsed.data.featured,
      bestSeller: parsed.data.bestSeller,
      isNew: parsed.data.isNew,
      price,
      stock,
      slug,
      variants: {
        deleteMany: {},
        create: parsed.data.variants.map((variant, index) => ({
          name: variant.name,
          price: variant.price,
          stock: variant.stock,
          isDefault: index === defaultIndex
        }))
      },
      pages: {
        set: parsed.data.pageIds.map((id) => ({ id }))
      }
    },
    include: {
      category: true,
      variants: true,
      pages: {
        select: { id: true, title: true, slug: true }
      }
    }
  });

  return NextResponse.json({ product: serializeProduct(product) });
}

export async function DELETE(_request: Request, { params }: Params) {
  const session = await getServerSession(authOptions);

  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const existing = await prisma.product.findUnique({
    where: { id: params.id },
    select: { id: true }
  });

  if (!existing) {
    return NextResponse.json({ message: "Product not found" }, { status: 404 });
  }

  await prisma.product.delete({
    where: { id: params.id }
  });

  return NextResponse.json({ ok: true });
}
