import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { serializeOrder } from "@/lib/mappers";
import { prisma } from "@/lib/prisma";
import { orderStatusSchema } from "@/lib/validators";

type Params = {
  params: {
    id: string;
  };
};

async function assertAdmin() {
  const session = await getServerSession(authOptions);

  return Boolean(session?.user && session.user.role === "ADMIN");
}

export async function GET(_request: Request, { params }: Params) {
  if (!(await assertAdmin())) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { items: true }
  });

  if (!order) {
    return NextResponse.json({ message: "Order not found" }, { status: 404 });
  }

  return NextResponse.json({ order: serializeOrder(order) });
}

export async function PATCH(request: Request, { params }: Params) {
  if (!(await assertAdmin())) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = orderStatusSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ message: "Invalid status", errors: parsed.error.flatten() }, { status: 400 });
  }

  const order = await prisma.order.update({
    where: { id: params.id },
    data: {
      status: parsed.data.status
    },
    include: { items: true }
  });

  return NextResponse.json({ order: serializeOrder(order) });
}
