import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

type CmsPageProps = {
  params: {
    slug: string;
  };
};

export default function OldCmsPage({ params }: CmsPageProps) {
  redirect(`/${params.slug}`);
}
