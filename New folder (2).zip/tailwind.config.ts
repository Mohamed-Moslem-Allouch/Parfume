import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        midnight: "#080808",
        obsidian: "#111111",
        charcoal: "#181818",
        gold: {
          DEFAULT: "#D4AF37",
          soft: "#E8C75C",
          deep: "#8A6A13"
        },
        mist: "#F5F5F5",
        muted: "#9CA3AF",
        rose: {
          DEFAULT: "#B74359",
          soft: "#D4637A"
        }
      },
      fontFamily: {
        heading: ["var(--font-playfair)", "serif"],
        body: ["var(--font-inter)", "sans-serif"]
      },
      boxShadow: {
        gold: "0 0 30px rgba(212, 175, 55, 0.18)",
        "gold-strong": "0 0 55px rgba(212, 175, 55, 0.28)"
      },
      backgroundImage: {
        "gold-gradient": "linear-gradient(135deg, #F8E08E 0%, #D4AF37 44%, #8A6A13 100%)"
      },
      keyframes: {
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" }
        },
        "pulse-gold": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(212, 175, 55, 0.4)" },
          "50%": { boxShadow: "0 0 0 8px rgba(212, 175, 55, 0)" }
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" }
        },
        "badge-glow": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.7" }
        }
      },
      animation: {
        shimmer: "shimmer 2.5s linear infinite",
        "pulse-gold": "pulse-gold 2s ease-in-out infinite",
        float: "float 3s ease-in-out infinite",
        "badge-glow": "badge-glow 2s ease-in-out infinite"
      }
    }
  },
  plugins: []
};

export default config;
