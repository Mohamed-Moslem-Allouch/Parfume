"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Globe, Menu, ShoppingBag, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Logo } from "@/components/logo";
import { useCart } from "@/components/providers/cart-provider";
import { useLanguage } from "@/components/providers/language-provider";
import type { PublicMenuItem } from "@/lib/menu";
import { cn } from "@/lib/utils";

export function HeaderClient({ menuItems }: { menuItems: PublicMenuItem[] }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const { itemCount, openCart } = useCart();
  const { locale, setLocale, t } = useLanguage();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-[70] border-b border-white/10 bg-[#080808] backdrop-blur-xl">
      <div className="section-shell flex h-20 items-center justify-between gap-4">
        <Logo />

        <nav className="hidden min-w-0 flex-1 items-center justify-center gap-2 px-4 lg:flex" aria-label="Main menu">
          {menuItems.map((item) => (
            <Link
              key={item.id}
              href={item.href}
              className={cn(
                "max-w-40 truncate rounded-md px-5 py-3 text-base font-bold text-muted transition hover:bg-white/5 hover:text-mist",
                (pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))) && "bg-white/5 text-gold"
              )}
              title={item.label}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {/* Language Toggle */}
          <button
            type="button"
            onClick={() => setLocale(locale === "en" ? "fr" : "en")}
            className="hidden items-center gap-2 rounded-md border-2 border-white/10 px-4 py-2.5 text-sm font-bold text-mist transition hover:border-gold hover:text-gold sm:inline-flex"
            aria-label="Toggle language"
            title="Toggle language"
          >
            <Globe className="h-5 w-5" />
            {locale === "en" ? "FRançais" : "ENglish"}
          </button>

          {/* Cart */}
          <button
            type="button"
            onClick={openCart}
            className="relative flex h-12 w-12 touch-manipulation items-center justify-center rounded-md border-2 border-white/10 text-mist transition hover:border-gold hover:text-gold"
            aria-label={t("nav.openCart")}
            title={t("nav.openCart")}
          >
            <ShoppingBag className="h-6 w-6" />
            {itemCount > 0 ? (
              <span className="absolute -right-2 -top-2 grid h-7 min-w-7 place-items-center rounded-full bg-gold px-1 text-sm font-bold text-midnight">
                {itemCount}
              </span>
            ) : null}
          </button>

          {/* Mobile menu toggle */}
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="flex h-12 w-12 touch-manipulation items-center justify-center rounded-md border-2 border-white/10 text-mist lg:hidden"
            aria-label={t("nav.toggleMenu")}
            title={t("nav.toggleMenu")}
            aria-expanded={open}
          >
            {open ? <X className="h-7 w-7 text-gold" /> : <Menu className="h-7 w-7" />}
          </button>
        </div>
      </div>

      {/* Mobile menu — Full screen premium dropdown */}
      <AnimatePresence>
        {open ? (
          <motion.div
            className="fixed inset-0 top-20 z-[65] flex flex-col bg-[#080808] lg:hidden"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
          >
            <nav className="flex-1 overflow-y-auto px-6 py-8" aria-label="Mobile menu">
              <div className="flex flex-col gap-4">
                {menuItems.map((item) => (
                  <Link
                    key={item.id}
                    href={item.href}
                    className={cn(
                      "block border-b border-white/10 py-5 text-2xl font-bold tracking-wide text-mist transition hover:text-gold",
                      (pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))) && "text-gold"
                    )}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>

              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  openCart();
                }}
                className="mt-8 flex w-full items-center justify-between rounded-lg bg-gold px-6 py-5 text-xl font-bold text-midnight"
              >
                <span className="inline-flex items-center gap-3">
                  <ShoppingBag className="h-6 w-6" />
                  {t("nav.cart")}
                </span>
                <span className="grid h-8 min-w-8 place-items-center rounded-full bg-midnight text-sm text-gold">
                  {itemCount}
                </span>
              </button>
            </nav>

            {/* Language toggle in mobile menu */}
            <div className="border-t border-white/10 p-6 pb-12">
              <p className="mb-4 text-center text-sm font-bold uppercase tracking-widest text-gold">Language / Langue</p>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setLocale("en")}
                  className={cn(
                    "flex min-h-14 items-center justify-center rounded-lg border-2 text-lg font-bold transition",
                    locale === "en" ? "border-gold bg-gold/10 text-gold" : "border-white/10 bg-transparent text-muted"
                  )}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => setLocale("fr")}
                  className={cn(
                    "flex min-h-14 items-center justify-center rounded-lg border-2 text-lg font-bold transition",
                    locale === "fr" ? "border-gold bg-gold/10 text-gold" : "border-white/10 bg-transparent text-muted"
                  )}
                >
                  Français
                </button>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
