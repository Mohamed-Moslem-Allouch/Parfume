"use client";

import Link from "next/link";
import { ExternalLink, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/logo";
import { storeConfig } from "@/lib/store";
import { useLanguage } from "@/components/providers/language-provider";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="border-t border-white/10 bg-[#060606] no-print">
      <div className="section-shell grid gap-10 py-12 md:grid-cols-[1.2fr_.8fr_.8fr]">
        <div>
          <Logo />
          <p className="mt-5 max-w-md text-sm leading-6 text-muted">
            {t("footer.description")}
          </p>
        </div>
        <div>
          <h3 className="font-heading text-lg text-gold">{t("footer.visit")}</h3>
          <div className="mt-4 space-y-3 text-sm text-muted">
            <p className="flex gap-3">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span>{storeConfig.address}</span>
            </p>
            <p className="flex gap-3">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span>{storeConfig.phone}</span>
            </p>
            <p className="flex gap-3">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span>{storeConfig.email}</span>
            </p>
          </div>
        </div>
        <div>
          <h3 className="font-heading text-lg text-gold">{t("footer.follow")}</h3>
          <div className="mt-4 flex items-center gap-3">
            <Link
              href="https://instagram.com"
              className="grid h-10 w-10 place-items-center rounded-md border border-white/10 text-muted transition hover:border-gold hover:text-gold"
              aria-label="Instagram"
            >
              <ExternalLink className="h-4 w-4" />
            </Link>
          </div>
          <p className="mt-6 text-xs text-muted">© {new Date().getFullYear()} {storeConfig.name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
