import { HeaderClient } from "@/components/header-client";
import { getPublicMenuItems } from "@/lib/menu";

export async function Header() {
  const menuItems = await getPublicMenuItems();

  return <HeaderClient menuItems={menuItems} />;
}
