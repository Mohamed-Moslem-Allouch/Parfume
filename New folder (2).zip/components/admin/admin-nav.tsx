"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { BarChart3, FileText, FolderTree, Home, LogOut, Menu as MenuIcon, Package, ReceiptText } from "lucide-react";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/utils";

const adminLinks = [
  { href: "/admin", label: "Dashboard", icon: BarChart3 },
  { href: "/admin/orders", label: "Orders", icon: ReceiptText },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/categories", label: "Categories", icon: FolderTree },
  { href: "/admin/pages", label: "Pages", icon: FileText },
  { href: "/admin/menu", label: "Menu", icon: MenuIcon }
];

export function AdminNav() {
  const pathname = usePathname();

  return (
    <aside className="border-b border-white/10 bg-obsidian lg:min-h-screen lg:border-b-0 lg:border-r">
      <div className="flex items-center justify-between gap-4 p-5 lg:block">
        <Logo />
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: "/admin/login" })}
          className="grid h-10 w-10 place-items-center rounded-md border border-white/10 text-muted hover:text-mist lg:hidden"
          aria-label="Sign out"
          title="Sign out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
      <nav className="flex gap-2 overflow-x-auto px-5 pb-5 lg:grid lg:px-4">
        {adminLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "flex items-center gap-3 rounded-md px-4 py-3 text-sm font-medium text-muted transition hover:bg-white/5 hover:text-mist",
              (pathname === link.href || (link.href !== "/admin" && pathname.startsWith(link.href))) && "bg-gold/10 text-gold"
            )}
          >
            <link.icon className="h-4 w-4" />
            {link.label}
          </Link>
        ))}
        <Link
          href="/"
          className="flex items-center gap-3 rounded-md px-4 py-3 text-sm font-medium text-muted transition hover:bg-white/5 hover:text-mist"
        >
          <Home className="h-4 w-4" />
          Storefront
        </Link>
      </nav>
      <div className="hidden px-4 pb-5 lg:block">
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: "/admin/login" })}
          className="flex w-full items-center gap-3 rounded-md px-4 py-3 text-sm font-medium text-muted transition hover:bg-white/5 hover:text-mist"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
