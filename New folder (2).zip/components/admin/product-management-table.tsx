"use client";

import Image from "next/image";
import Link from "next/link";
import { Edit3, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { DeleteProductButton } from "@/components/admin/delete-product-button";
import { formatCurrency, formatDate } from "@/lib/format";

type CategoryOption = {
  id: string;
  name: string;
  slug: string;
};

type PageOption = {
  id: string;
  title: string;
  slug: string;
};

type ProductRow = {
  id: string;
  name: string;
  slug: string;
  images: string[];
  price: number;
  stock: number;
  featured: boolean;
  updatedAt: string;
  category: CategoryOption;
  variants: { id: string; name: string; stock: number }[];
  pages: PageOption[];
};

export function ProductManagementTable({
  products,
  categories,
  pages
}: {
  products: ProductRow[];
  categories: CategoryOption[];
  pages: PageOption[];
}) {
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [stockFilter, setStockFilter] = useState("all");
  const [pageFilter, setPageFilter] = useState("all");
  const [featuredFilter, setFeaturedFilter] = useState("all");
  const [sort, setSort] = useState("newest");

  const filteredProducts = useMemo(() => {
    const term = search.trim().toLowerCase();

    return products
      .filter((product) => {
        const matchesSearch =
          !term ||
          product.name.toLowerCase().includes(term) ||
          product.slug.toLowerCase().includes(term) ||
          product.category.name.toLowerCase().includes(term) ||
          product.pages.some((page) => page.title.toLowerCase().includes(term));
        const matchesCategory = !categoryId || product.category.id === categoryId;
        const matchesStock =
          stockFilter === "all" ||
          (stockFilter === "in-stock" && product.stock > 5) ||
          (stockFilter === "low-stock" && product.stock > 0 && product.stock <= 5) ||
          (stockFilter === "out-of-stock" && product.stock <= 0);
        const matchesPage =
          pageFilter === "all" ||
          (pageFilter === "unassigned" && product.pages.length === 0) ||
          product.pages.some((page) => page.id === pageFilter);
        const matchesFeatured =
          featuredFilter === "all" ||
          (featuredFilter === "featured" && product.featured) ||
          (featuredFilter === "normal" && !product.featured);

        return matchesSearch && matchesCategory && matchesStock && matchesPage && matchesFeatured;
      })
      .sort((a, b) => {
        if (sort === "name") {
          return a.name.localeCompare(b.name);
        }

        if (sort === "price-low") {
          return a.price - b.price;
        }

        if (sort === "price-high") {
          return b.price - a.price;
        }

        if (sort === "stock-low") {
          return a.stock - b.stock;
        }

        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      });
  }, [categoryId, featuredFilter, pageFilter, products, search, sort, stockFilter]);

  return (
    <section className="overflow-hidden rounded-md border border-white/10 bg-obsidian">
      <div className="grid gap-3 border-b border-white/10 p-4 lg:grid-cols-[minmax(220px,1fr)_170px_150px_180px_150px_150px]">
        <label className="relative">
          <span className="sr-only">Search products</span>
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} className="input-field pl-11" placeholder="Search products..." />
        </label>
        <label>
          <span className="sr-only">Filter by category</span>
          <select value={categoryId} onChange={(event) => setCategoryId(event.target.value)} className="input-field">
            <option value="">All categories</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="sr-only">Filter by stock</span>
          <select value={stockFilter} onChange={(event) => setStockFilter(event.target.value)} className="input-field">
            <option value="all">All stock</option>
            <option value="in-stock">In stock</option>
            <option value="low-stock">Low stock</option>
            <option value="out-of-stock">Out of stock</option>
          </select>
        </label>
        <label>
          <span className="sr-only">Filter by page</span>
          <select value={pageFilter} onChange={(event) => setPageFilter(event.target.value)} className="input-field">
            <option value="all">All pages</option>
            <option value="unassigned">Not on any page</option>
            {pages.map((page) => (
              <option key={page.id} value={page.id}>
                {page.title}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="sr-only">Filter by featured status</span>
          <select value={featuredFilter} onChange={(event) => setFeaturedFilter(event.target.value)} className="input-field">
            <option value="all">All visibility</option>
            <option value="featured">Featured</option>
            <option value="normal">Not featured</option>
          </select>
        </label>
        <label>
          <span className="sr-only">Sort products</span>
          <select value={sort} onChange={(event) => setSort(event.target.value)} className="input-field">
            <option value="newest">Recently updated</option>
            <option value="name">Name A-Z</option>
            <option value="price-low">Price low-high</option>
            <option value="price-high">Price high-low</option>
            <option value="stock-low">Stock low first</option>
          </select>
        </label>
      </div>

      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3 text-sm text-muted">
        <span>
          Showing <strong className="text-mist">{filteredProducts.length}</strong> of <strong className="text-mist">{products.length}</strong> products
        </span>
        <button
          type="button"
          onClick={() => {
            setSearch("");
            setCategoryId("");
            setStockFilter("all");
            setPageFilter("all");
            setFeaturedFilter("all");
            setSort("newest");
          }}
          className="rounded-md px-3 py-2 text-gold transition hover:bg-gold/10"
        >
          Clear filters
        </button>
      </div>

      <div className="hidden border-b border-white/10 px-4 py-3 text-xs uppercase tracking-[0.18em] text-muted lg:grid lg:grid-cols-[minmax(280px,1.7fr)_150px_130px_160px_1fr_100px]">
        <span>Product</span>
        <span>Category</span>
        <span>Price</span>
        <span>Stock</span>
        <span>Pages</span>
        <span className="text-right">Actions</span>
      </div>

      <div className="divide-y divide-white/10">
        {filteredProducts.map((product) => {
          const image = product.images[0] || "/products/royal-saffron-oud.svg";

          return (
            <article key={product.id} className="grid gap-4 p-4 lg:grid-cols-[minmax(280px,1.7fr)_150px_130px_160px_1fr_100px] lg:items-center">
              <div className="flex min-w-0 items-center gap-3">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md bg-charcoal">
                  <Image src={image} alt={product.name} fill className="object-cover" sizes="64px" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="truncate font-medium text-mist">{product.name}</p>
                    {product.featured ? <span className="rounded-md bg-gold/15 px-2 py-1 text-xs font-bold text-gold">Featured</span> : null}
                  </div>
                  <p className="truncate text-xs text-muted">/{product.slug}</p>
                  <p className="mt-1 text-xs text-muted lg:hidden">{product.category.name}</p>
                </div>
              </div>

              <p className="text-sm text-muted max-lg:hidden">{product.category.name}</p>
              <p className="text-sm font-bold text-gold">From {formatCurrency(product.price)}</p>
              <p className="text-sm text-muted">
                {product.stock}
                <span className="ml-2 text-xs text-muted">({product.variants.length} options)</span>
              </p>
              <div className="flex flex-wrap gap-2 text-xs text-muted">
                {product.pages.length ? (
                  product.pages.slice(0, 3).map((page) => (
                    <span key={page.id} className="rounded-md bg-white/5 px-2 py-1">
                      {page.title}
                    </span>
                  ))
                ) : (
                  <span className="rounded-md bg-white/5 px-2 py-1">No page</span>
                )}
                {product.pages.length > 3 ? <span className="rounded-md bg-white/5 px-2 py-1">+{product.pages.length - 3}</span> : null}
                <span className="basis-full text-[11px] text-muted">Updated {formatDate(product.updatedAt)}</span>
              </div>
              <div className="flex justify-end gap-2">
                <Link
                  href={`/admin/products/${product.id}/edit`}
                  className="grid h-10 w-10 place-items-center rounded-md text-muted transition hover:bg-white/5 hover:text-gold"
                  aria-label={`Edit ${product.name}`}
                  title="Edit product"
                >
                  <Edit3 className="h-4 w-4" />
                </Link>
                <DeleteProductButton productId={product.id} productName={product.name} />
              </div>
            </article>
          );
        })}
      </div>

      {!filteredProducts.length ? (
        <div className="px-6 py-16 text-center">
          <p className="font-heading text-2xl text-mist">No products found</p>
          <p className="mt-2 text-sm text-muted">Clear the filters or add a new product.</p>
        </div>
      ) : null}
    </section>
  );
}
