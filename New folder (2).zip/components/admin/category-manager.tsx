"use client";

import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Plus, Save, Trash2 } from "lucide-react";

type Category = {
  id: string;
  name: string;
  slug: string;
  _count: {
    products: number;
  };
};

export function CategoryManager({ categories }: { categories: Category[] }) {
  const router = useRouter();
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState<Record<string, string>>(() =>
    Object.fromEntries(categories.map((category) => [category.id, category.name]))
  );
  const [message, setMessage] = useState("");

  async function createCategory(event: FormEvent) {
    event.preventDefault();
    setMessage("");

    const response = await fetch("/api/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName })
    });

    if (!response.ok) {
      const data = (await response.json()) as { message?: string };
      setMessage(data.message || "Unable to create category.");
      return;
    }

    setNewName("");
    router.refresh();
  }

  async function saveCategory(id: string) {
    setMessage("");

    const response = await fetch(`/api/categories/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: editing[id] })
    });

    if (!response.ok) {
      const data = (await response.json()) as { message?: string };
      setMessage(data.message || "Unable to save category.");
      return;
    }

    router.refresh();
  }

  async function deleteCategory(id: string) {
    if (!window.confirm("Delete this category?")) {
      return;
    }

    setMessage("");

    const response = await fetch(`/api/categories/${id}`, {
      method: "DELETE"
    });

    if (!response.ok) {
      const data = (await response.json()) as { message?: string };
      setMessage(data.message || "Unable to delete category.");
      return;
    }

    router.refresh();
  }

  return (
    <div className="grid gap-6">
      <form onSubmit={createCategory} className="grid gap-3 rounded-md border border-white/10 bg-obsidian p-5 sm:grid-cols-[1fr_auto]">
        <input value={newName} onChange={(event) => setNewName(event.target.value)} className="input-field" placeholder="New category name" required />
        <button type="submit" className="btn-primary">
          <Plus className="h-4 w-4" />
          Add Category
        </button>
      </form>

      {message ? <p className="rounded-md border border-red-400/30 bg-red-950/30 p-3 text-sm text-red-200">{message}</p> : null}

      <div className="rounded-md border border-white/10 bg-obsidian">
        <div className="divide-y divide-white/10">
          {categories.map((category) => (
            <div key={category.id} className="grid gap-3 p-4 md:grid-cols-[1fr_180px_110px] md:items-center">
              <div>
                <input
                  value={editing[category.id] || ""}
                  onChange={(event) => setEditing((current) => ({ ...current, [category.id]: event.target.value }))}
                  className="input-field"
                />
                <p className="mt-1 text-xs text-muted">/{category.slug}</p>
              </div>
              <p className="text-sm text-muted">{category._count.products} products</p>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => saveCategory(category.id)} className="grid h-10 w-10 place-items-center rounded-md text-muted hover:bg-white/5 hover:text-gold" aria-label="Save category" title="Save category">
                  <Save className="h-4 w-4" />
                </button>
                <button type="button" onClick={() => deleteCategory(category.id)} className="grid h-10 w-10 place-items-center rounded-md text-muted hover:bg-red-950/40 hover:text-red-200" aria-label="Delete category" title="Delete category">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
