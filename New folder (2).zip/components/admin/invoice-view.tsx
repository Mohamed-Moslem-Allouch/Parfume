"use client";

import { FileText, Printer } from "lucide-react";
import { storeConfig } from "@/lib/store";
import { formatCurrency, formatDate, toNumber } from "@/lib/format";

type InvoiceItem = {
  id: string;
  productName: string;
  variantName: string | null;
  productPrice: { toString: () => string } | number;
  quantity: number;
};

type InvoiceOrder = {
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryMethod: string;
  address: string | null;
  city: string | null;
  zip: string | null;
  notes: string | null;
  subtotal: { toString: () => string } | number;
  deliveryFee: { toString: () => string } | number;
  total: { toString: () => string } | number;
  status: string;
  createdAt: Date | string;
  items: InvoiceItem[];
};

export function InvoiceView({ order }: { order: InvoiceOrder }) {
  function handlePrint() {
    window.print();
  }



  return (
    <div className="grid gap-4">
      <div className="flex gap-3 no-print">
        <button type="button" onClick={handlePrint} className="btn-primary">
          <Printer className="h-4 w-4" />
          Print / Save as PDF
        </button>
      </div>

      {/* Invoice */}
      <div className="invoice-container rounded-lg border border-white/10 bg-obsidian overflow-hidden">
        {/* Header */}
        <div className="invoice-header border-b border-white/10 bg-charcoal p-6 sm:p-8">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-start">
            <div>
              <h2 className="font-heading text-3xl font-bold text-gold sm:text-4xl">{storeConfig.name}</h2>
              <p className="mt-2 text-sm text-muted">{storeConfig.address}</p>
              <p className="text-sm text-muted">{storeConfig.phone}</p>
              <p className="text-sm text-muted">{storeConfig.email}</p>
            </div>
            <div className="text-left sm:text-right">
              <p className="text-xs uppercase tracking-[0.2em] text-gold">Invoice</p>
              <p className="mt-2 font-heading text-2xl font-bold text-mist">{order.orderNumber}</p>
              <p className="mt-1 text-sm text-muted">{formatDate(order.createdAt)}</p>
              <p className="mt-2 inline-block rounded-md bg-gold/15 px-3 py-1 text-xs font-bold text-gold">
                {order.status}
              </p>
            </div>
          </div>
        </div>

        {/* Customer & Delivery */}
        <div className="grid gap-6 border-b border-white/10 p-6 sm:grid-cols-2 sm:p-8">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-gold">Bill To</p>
            <div className="mt-3 space-y-1 text-sm">
              <p className="font-medium text-mist">{order.customerName}</p>
              <p className="text-muted">{order.customerEmail}</p>
              <p className="text-muted">{order.customerPhone}</p>
            </div>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-gold">Delivery</p>
            <div className="mt-3 space-y-1 text-sm">
              <p className="font-medium text-mist">
                {order.deliveryMethod === "HOME_DELIVERY" ? "Home Delivery" : "Store Pickup"}
              </p>
              {order.deliveryMethod === "HOME_DELIVERY" && (
                <p className="text-muted">
                  {[order.address, order.city, order.zip].filter(Boolean).join(", ")}
                </p>
              )}
              {order.notes && <p className="text-muted">Notes: {order.notes}</p>}
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="p-6 sm:p-8">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10 text-xs uppercase tracking-[0.15em] text-gold">
                <th className="pb-3 text-left font-medium">Item</th>
                <th className="pb-3 text-center font-medium">Qty</th>
                <th className="pb-3 text-right font-medium">Unit Price</th>
                <th className="pb-3 text-right font-medium">Total</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {order.items.map((item) => {
                const price = toNumber(item.productPrice);
                const lineTotal = price * item.quantity;
                return (
                  <tr key={item.id} className="border-b border-white/5">
                    <td className="py-3 pr-4">
                      <p className="font-medium text-mist">{item.productName}</p>
                      {item.variantName && <p className="text-xs text-muted">{item.variantName}</p>}
                    </td>
                    <td className="py-3 text-center text-muted">{item.quantity}</td>
                    <td className="py-3 text-right text-muted">{formatCurrency(price)}</td>
                    <td className="py-3 text-right font-medium text-mist">{formatCurrency(lineTotal)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Totals */}
          <div className="mt-6 flex justify-end">
            <div className="w-full max-w-xs space-y-2">
              <div className="flex justify-between text-sm text-muted">
                <span>Subtotal</span>
                <span className="text-mist">{formatCurrency(toNumber(order.subtotal))}</span>
              </div>
              <div className="flex justify-between text-sm text-muted">
                <span>Delivery Fee</span>
                <span className="text-mist">{formatCurrency(toNumber(order.deliveryFee))}</span>
              </div>
              <div className="invoice-total flex justify-between rounded-md bg-gold/10 p-3 text-base font-bold">
                <span className="text-gold">Grand Total</span>
                <span className="text-gold">{formatCurrency(toNumber(order.total))}</span>
              </div>
            </div>
          </div>

          {/* Thank you note */}
          <div className="mt-8 border-t border-white/10 pt-6 text-center">
            <p className="text-sm text-muted">Thank you for your purchase!</p>
            <p className="mt-1 text-xs text-muted/60">{storeConfig.name} — {storeConfig.address}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
