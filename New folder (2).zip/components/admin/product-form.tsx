"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { ChangeEvent, FormEvent, useMemo, useState } from "react";
import { ImagePlus, Plus, Save, Trash2, Video, X } from "lucide-react";
import type { SerializedProduct } from "@/lib/mappers";

type Category = {
  id: string;
  name: string;
};

type CmsPage = {
  id: string;
  title: string;
  slug: string;
};

type VariantDraft = {
  name: string;
  price: number;
  stock: number;
  isDefault: boolean;
};

const defaultVariants: VariantDraft[] = [
  { name: "50 ml", price: 0, stock: 0, isDefault: true },
  { name: "100 ml", price: 0, stock: 0, isDefault: false }
];

export function ProductForm({
  categories,
  pages,
  product
}: {
  categories: Category[];
  pages: CmsPage[];
  product?: SerializedProduct;
}) {
  const router = useRouter();
  const [images, setImages] = useState<string[]>(product?.images || []);
  const [videos, setVideos] = useState<string[]>(product?.videos || []);
  const [variants, setVariants] = useState<VariantDraft[]>(
    product?.variants.length
      ? product.variants.map((variant, index) => ({
          name: variant.name,
          price: variant.price,
          stock: variant.stock,
          isDefault: variant.isDefault || index === 0
        }))
      : defaultVariants
  );
  const [pageIds, setPageIds] = useState<string[]>(product?.pageIds || []);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const totalStock = useMemo(() => variants.reduce((sum, variant) => sum + Number(variant.stock || 0), 0), [variants]);
  const minPrice = useMemo(
    () => Math.min(...variants.filter((variant) => Number(variant.price) > 0).map((variant) => Number(variant.price))),
    [variants]
  );

  async function handleUpload(event: ChangeEvent<HTMLInputElement>, kind: "images" | "videos") {
    const files = Array.from(event.target.files || []);

    if (!files.length) {
      return;
    }

    const formData = new FormData();
    files.forEach((file) => formData.append(kind, file));
    setUploading(true);
    setError("");

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData
      });
      const data = (await response.json()) as { urls?: string[]; message?: string };

      if (!response.ok || !data.urls) {
        throw new Error(data.message || "Unable to upload files.");
      }

      if (kind === "images") {
        setImages((current) => [...current, ...data.urls!].slice(0, 16));
      } else {
        setVideos((current) => [...current, ...data.urls!].slice(0, 8));
      }
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : "Unable to upload files.");
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  }

  function updateVariant(index: number, patch: Partial<VariantDraft>) {
    setVariants((current) =>
      current.map((variant, candidateIndex) =>
        candidateIndex === index
          ? {
              ...variant,
              ...patch
            }
          : patch.isDefault
            ? { ...variant, isDefault: false }
            : variant
      )
    );
  }

  function removeVariant(index: number) {
    setVariants((current) => {
      const next = current.filter((_, candidateIndex) => candidateIndex !== index);

      if (!next.some((variant) => variant.isDefault) && next[0]) {
        next[0].isDefault = true;
      }

      return next;
    });
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");

    const formData = new FormData(event.currentTarget);
    const validVariants = variants
      .map((variant) => ({
        ...variant,
        name: variant.name.trim(),
        price: Number(variant.price),
        stock: Number(variant.stock)
      }))
      .filter((variant) => variant.name && variant.price > 0);

    if (!validVariants.length) {
      setSaving(false);
      setError("Add at least one size or option with a valid price.");
      return;
    }

    if (!validVariants.some((variant) => variant.isDefault)) {
      validVariants[0].isDefault = true;
    }

    const payload = {
      name: String(formData.get("name") || ""),
      description: String(formData.get("description") || ""),
      categoryId: String(formData.get("categoryId") || ""),
      featured: formData.get("featured") === "on",
      bestSeller: formData.get("bestSeller") === "on",
      isNew: formData.get("isNew") === "on",
      images,
      videos,
      variants: validVariants,
      pageIds
    };

    try {
      const response = await fetch(product ? `/api/products/${product.id}` : "/api/products", {
        method: product ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      const data = (await response.json()) as { message?: string };

      if (!response.ok) {
        throw new Error(data.message || "Unable to save product.");
      }

      router.push("/admin/products");
      router.refresh();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Unable to save product.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-6 xl:grid-cols-[1fr_420px]">
      <div className="grid gap-6">
        <section className="grid gap-6 rounded-lg border border-white/10 bg-obsidian p-5 sm:p-6">
          <label>
            <span className="label">Name</span>
            <input name="name" defaultValue={product?.name} required minLength={2} className="input-field" />
          </label>
          <label>
            <span className="label">Description</span>
            <textarea
              name="description"
              defaultValue={product?.description}
              required
              minLength={10}
              rows={8}
              className="input-field resize-none"
            />
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label>
              <span className="label">Category</span>
              <select name="categoryId" defaultValue={product?.category.id || categories[0]?.id} required className="input-field">
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="rounded-lg border border-white/10 bg-midnight p-4">
              <p className="text-sm text-muted">Computed catalog values</p>
              <p className="mt-2 text-sm text-mist">
                From <span className="font-bold text-gold">{Number.isFinite(minPrice) ? `${minPrice} TND` : "0 TND"}</span> · {totalStock} units
              </p>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <label className="flex items-center gap-3 rounded-lg border border-white/10 bg-midnight p-4 text-sm text-mist">
              <input name="featured" type="checkbox" defaultChecked={product?.featured} className="h-4 w-4 accent-gold" />
              Featured
            </label>
            <label className="flex items-center gap-3 rounded-lg border border-white/10 bg-midnight p-4 text-sm text-mist">
              <input name="bestSeller" type="checkbox" defaultChecked={product?.bestSeller} className="h-4 w-4 accent-gold" />
              Best Seller
            </label>
            <label className="flex items-center gap-3 rounded-lg border border-white/10 bg-midnight p-4 text-sm text-mist">
              <input name="isNew" type="checkbox" defaultChecked={product?.isNew} className="h-4 w-4 accent-gold" />
              New Arrival
            </label>
          </div>
        </section>

        <section className="rounded-lg border border-white/10 bg-obsidian p-5 sm:p-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="font-heading text-2xl text-mist">Sizes and options</h2>
              <p className="mt-1 text-sm text-muted">Create 50 ml, 100 ml, testers, gift sets, or any custom option.</p>
            </div>
            <button
              type="button"
              onClick={() => setVariants((current) => [...current, { name: "", price: 0, stock: 0, isDefault: false }])}
              className="btn-secondary shrink-0"
            >
              <Plus className="h-4 w-4" />
              Add Option
            </button>
          </div>
          <div className="mt-5 grid gap-3">
            {variants.map((variant, index) => (
              <div key={index} className="grid gap-3 rounded-lg border border-white/10 bg-midnight p-4 md:grid-cols-[1fr_130px_120px_110px_44px]">
                <label>
                  <span className="label">Option</span>
                  <input
                    value={variant.name}
                    onChange={(event) => updateVariant(index, { name: event.target.value })}
                    placeholder="50 ml"
                    className="input-field"
                  />
                </label>
                <label>
                  <span className="label">Price TND</span>
                  <input
                    type="number"
                    min="0"
                    step="0.001"
                    value={variant.price}
                    onChange={(event) => updateVariant(index, { price: Number(event.target.value) })}
                    className="input-field"
                  />
                </label>
                <label>
                  <span className="label">Stock</span>
                  <input
                    type="number"
                    min="0"
                    value={variant.stock}
                    onChange={(event) => updateVariant(index, { stock: Number(event.target.value) })}
                    className="input-field"
                  />
                </label>
                <label className="flex items-end gap-2 pb-3 text-sm text-muted">
                  <input
                    type="radio"
                    name="defaultVariant"
                    checked={variant.isDefault}
                    onChange={() => updateVariant(index, { isDefault: true })}
                    className="h-4 w-4 accent-gold"
                  />
                  Default
                </label>
                <button
                  type="button"
                  onClick={() => removeVariant(index)}
                  disabled={variants.length <= 1}
                  className="mt-auto grid h-11 w-11 place-items-center rounded-md text-muted hover:bg-red-950/40 hover:text-red-200 disabled:opacity-40"
                  aria-label="Remove option"
                  title="Remove option"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-lg border border-white/10 bg-obsidian p-5 sm:p-6">
          <h2 className="font-heading text-2xl text-mist">Page visibility</h2>
          <p className="mt-1 text-sm text-muted">Choose which custom pages should display this product.</p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {pages.length ? (
              pages.map((page) => (
                <label key={page.id} className="flex items-center gap-3 rounded-lg border border-white/10 bg-midnight p-4 text-sm text-mist">
                  <input
                    type="checkbox"
                    checked={pageIds.includes(page.id)}
                    onChange={(event) =>
                      setPageIds((current) =>
                        event.target.checked ? [...current, page.id] : current.filter((id) => id !== page.id)
                      )
                    }
                    className="h-4 w-4 accent-gold"
                  />
                  <span>
                    {page.title}
                    <span className="block text-xs text-muted">/{page.slug}</span>
                  </span>
                </label>
              ))
            ) : (
              <p className="text-sm text-muted">Create custom pages first, then assign products to them.</p>
            )}
          </div>
        </section>

        {error ? <p className="rounded-lg border border-red-400/30 bg-red-950/30 p-3 text-sm text-red-200">{error}</p> : null}
        <button type="submit" disabled={saving || uploading || !categories.length} className="btn-primary w-fit">
          <Save className="h-4 w-4" />
          {saving ? "Saving..." : "Save Product"}
        </button>
      </div>

      <aside className="grid h-fit gap-6">
        <section className="rounded-lg border border-white/10 bg-obsidian p-5 sm:p-6">
          <h2 className="font-heading text-2xl text-mist">Images</h2>
          <p className="mt-2 text-sm text-muted">Upload up to 16 images (JPG, PNG, WebP, GIF, AVIF, HEIC, SVG). Max 10MB each.</p>
          <label className="mt-5 flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-gold/35 bg-midnight p-5 text-center text-sm text-muted transition hover:border-gold hover:text-mist">
            <ImagePlus className="mb-2 h-6 w-6 text-gold" />
            {uploading ? "Uploading..." : "Choose images"}
            <input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic,image/heif,image/svg+xml" multiple onChange={(event) => handleUpload(event, "images")} className="sr-only" disabled={uploading} />
          </label>
          <div className="mt-5 grid grid-cols-2 gap-3">
            {images.map((image) => (
              <div key={image} className="group relative aspect-square overflow-hidden rounded-lg border border-white/10 bg-charcoal">
                <Image src={image} alt="Product upload preview" fill className="object-cover" sizes="160px" />
                <button
                  type="button"
                  onClick={() => setImages((current) => current.filter((item) => item !== image))}
                  className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-md bg-black/70 text-white opacity-0 transition group-hover:opacity-100"
                  aria-label="Remove image"
                  title="Remove image"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-lg border border-white/10 bg-obsidian p-5 sm:p-6">
          <h2 className="font-heading text-2xl text-mist">Videos</h2>
          <p className="mt-2 text-sm text-muted">Upload MP4, WebM, or MOV videos. Max 50MB each.</p>
          <label className="mt-5 flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-gold/35 bg-midnight p-5 text-center text-sm text-muted transition hover:border-gold hover:text-mist">
            <Video className="mb-2 h-6 w-6 text-gold" />
            {uploading ? "Uploading..." : "Choose videos"}
            <input type="file" accept="video/mp4,video/webm,video/quicktime" multiple onChange={(event) => handleUpload(event, "videos")} className="sr-only" disabled={uploading} />
          </label>
          <div className="mt-5 grid gap-3">
            {videos.map((video) => (
              <div key={video} className="group relative overflow-hidden rounded-lg border border-white/10 bg-charcoal">
                <video src={video} controls className="aspect-video w-full object-cover" />
                <button
                  type="button"
                  onClick={() => setVideos((current) => current.filter((item) => item !== video))}
                  className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-md bg-black/70 text-white opacity-0 transition group-hover:opacity-100"
                  aria-label="Remove video"
                  title="Remove video"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </section>
      </aside>
    </form>
  );
}
