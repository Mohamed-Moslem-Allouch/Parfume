"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { AddToCartButton } from "@/components/add-to-cart-button";
import type { SerializedProduct } from "@/lib/mappers";
import { formatCurrency } from "@/lib/format";
import { useLanguage } from "@/components/providers/language-provider";

export function ProductCard({ product }: { product: SerializedProduct }) {
  const { t } = useLanguage();
  const image = product.images[0] || "/products/royal-saffron-oud.svg";
  const defaultVariant = product.variants.find((variant) => variant.isDefault) || product.variants[0];
  const totalStock = product.variants.reduce((sum, variant) => sum + variant.stock, 0);
  const showNew = product.isNew;
  const showBestSeller = product.bestSeller;

  return (
    <motion.article
      whileHover={{ y: -4, scale: 1.01 }}
      transition={{ duration: 0.2 }}
      className="group flex h-full flex-col overflow-hidden rounded-lg border border-white/10 bg-obsidian transition hover:border-gold/60 hover:shadow-gold"
    >
      <Link href={`/products/${product.slug}`} className="relative block aspect-square overflow-hidden bg-charcoal">
        <Image src={image} alt={product.name} fill className="object-cover transition duration-500 group-hover:scale-105" sizes="(min-width: 1280px) 20vw, (min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw" />
        {showNew && <span className="badge-new">{t("product.new")}</span>}
        {showBestSeller && <span className="badge-bestseller">{t("product.bestSeller")}</span>}
        {totalStock <= 0 && <span className="badge-soldout">{t("product.soldOut")}</span>}
      </Link>
      <div className="flex flex-1 flex-col p-2.5">
        <p className="text-[9px] uppercase tracking-[0.14em] text-gold sm:text-[10px]">{product.category.name}</p>
        <Link href={`/products/${product.slug}`} className="mt-1 block font-heading text-sm leading-snug text-mist transition hover:text-gold">
          {product.name}
        </Link>
        <p className="mt-1 text-xs font-bold text-gold">{t("product.from")} {formatCurrency(product.price)}</p>
        <div className="mt-auto pt-2">
          {defaultVariant ? (
            <AddToCartButton
              product={{
                id: product.id,
                variantId: defaultVariant.id,
                variantName: defaultVariant.name,
                name: product.name,
                slug: product.slug,
                price: defaultVariant.price,
                image,
                stock: defaultVariant.stock
              }}
              className="btn-secondary min-h-9 w-full px-2 text-[11px] sm:min-h-10 sm:px-3 sm:text-xs"
            />
          ) : (
            <button type="button" disabled className="btn-secondary min-h-9 w-full px-2 text-[11px] sm:min-h-10 sm:px-3 sm:text-xs">
              {t("product.noOptions")}
            </button>
          )}
        </div>
      </div>
    </motion.article>
  );
}
