"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";

export type Locale = "en" | "fr";

type LanguageContextValue = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
};

const translations: Record<Locale, Record<string, string>> = {
  en: {
    // Header / Nav
    "nav.home": "Home",
    "nav.shop": "Shop",
    "nav.cart": "Cart",
    "nav.openCart": "Open cart",
    "nav.toggleMenu": "Toggle menu",

    // Hero
    "hero.badge": "Beauty & Fragrance Store",
    "hero.title.part1": "Discover the scent that leaves a ",
    "hero.title.highlight": "golden memory",
    "hero.title.part2": ".",
    "hero.subtitle": "Shop refined perfumes, body care, oils, and premium beauty products with store pickup or home delivery.",
    "hero.cta": "Shop Now",
    "hero.ctaSecondary": "Featured Products",

    // Sections
    "featured.label": "Featured products",
    "featured.title": "Bestsellers with a quiet glow",
    "featured.viewAll": "View All",
    "newArrivals.label": "Just arrived",
    "newArrivals.title": "New Arrivals",
    "bestSellers.label": "Most loved",
    "bestSellers.title": "Best Sellers",
    "categories.label": "Browse by type",
    "categories.title": "Shop by Category",
    "whyUs.label": "Why choose us",
    "whyUs.title": "Carefully selected products, handled with boutique-level care.",
    "whyUs.curated": "Curated selection",
    "whyUs.curatedText": "Each product is selected for quality, character, and premium experience.",
    "whyUs.secure": "Secure admin CMS",
    "whyUs.secureText": "Stock, images, and orders are managed from a protected web panel.",
    "whyUs.delivery": "Flexible delivery",
    "whyUs.deliveryText": "Customers choose home delivery or pickup from the store during checkout.",
    "store.label": "Store location",
    "store.title": "Visit our store",
    "store.planPickup": "Plan Pickup",
    "store.browseFirst": "Browse First",

    // Shop page
    "shop.label": "Shop",
    "shop.title": "Our full collection",
    "shop.subtitle": "Search the full collection, filter by category, and sort by price.",
    "shop.searchPlaceholder": "Search products...",
    "shop.allCategories": "All categories",
    "shop.newest": "Newest",
    "shop.priceLow": "Price low-high",
    "shop.priceHigh": "Price high-low",
    "shop.emptyTitle": "No products found",
    "shop.emptyText": "Try a different search or category.",
    "shop.page": "Page",
    "shop.of": "of",

    // Product
    "product.soldOut": "Sold out",
    "product.from": "From",
    "product.noOptions": "No Options",
    "product.addToCart": "Add to Cart",
    "product.new": "NEW",
    "product.bestSeller": "BEST SELLER",
    "product.related": "Related products",
    "product.relatedTitle": "You may also like",
    "product.inStock": "units in stock",
    "product.outOfStock": "Out of stock",

    // Cart
    "cart.title": "Your Cart",
    "cart.close": "Close cart",
    "cart.empty": "Your cart is empty",
    "cart.emptyHint": "Add a product and it will appear here.",
    "cart.subtotal": "Subtotal",
    "cart.checkout": "Proceed to Checkout",
    "cart.viewCart": "View Cart",

    // Footer
    "footer.description": "Premium perfumes, body care, oils, and beauty products selected for depth, elegance, and quality.",
    "footer.visit": "Visit",
    "footer.follow": "Follow",

    // Invoice
    "invoice.title": "Invoice",
    "invoice.date": "Date",
    "invoice.orderNumber": "Order #",
    "invoice.billTo": "Bill To",
    "invoice.deliveryMethod": "Delivery Method",
    "invoice.homeDelivery": "Home Delivery",
    "invoice.storePickup": "Store Pickup",
    "invoice.item": "Item",
    "invoice.qty": "Qty",
    "invoice.unitPrice": "Unit Price",
    "invoice.total": "Total",
    "invoice.subtotal": "Subtotal",
    "invoice.deliveryFee": "Delivery Fee",
    "invoice.grandTotal": "Grand Total",
    "invoice.print": "Print Invoice",
    "invoice.exportPdf": "Export PDF",
    "invoice.thankYou": "Thank you for your purchase!",

    // Language
    "lang.en": "EN",
    "lang.fr": "FR"
  },
  fr: {
    // Header / Nav
    "nav.home": "Accueil",
    "nav.shop": "Boutique",
    "nav.cart": "Panier",
    "nav.openCart": "Ouvrir le panier",
    "nav.toggleMenu": "Menu",

    // Hero
    "hero.badge": "Beauté & Parfumerie",
    "hero.title.part1": "Découvrez le parfum qui laisse un ",
    "hero.title.highlight": "souvenir doré",
    "hero.title.part2": ".",
    "hero.subtitle": "Découvrez nos parfums raffinés, soins du corps, huiles et produits de beauté haut de gamme avec retrait en boutique ou livraison à domicile.",
    "hero.cta": "Acheter",
    "hero.ctaSecondary": "Produits vedettes",

    // Sections
    "featured.label": "Produits vedettes",
    "featured.title": "Les plus vendus avec une touche dorée",
    "featured.viewAll": "Voir Tout",
    "newArrivals.label": "Nouveautés",
    "newArrivals.title": "Nouvelles arrivées",
    "bestSellers.label": "Les plus aimés",
    "bestSellers.title": "Meilleures ventes",
    "categories.label": "Parcourir par type",
    "categories.title": "Acheter par catégorie",
    "whyUs.label": "Pourquoi nous choisir",
    "whyUs.title": "Des produits soigneusement sélectionnés, traités avec un soin de boutique.",
    "whyUs.curated": "Sélection raffinée",
    "whyUs.curatedText": "Chaque produit est sélectionné pour sa qualité, son caractère et son expérience premium.",
    "whyUs.secure": "CMS admin sécurisé",
    "whyUs.secureText": "Stock, images et commandes sont gérés depuis un panneau web protégé.",
    "whyUs.delivery": "Livraison flexible",
    "whyUs.deliveryText": "Les clients choisissent la livraison à domicile ou le retrait en boutique lors du paiement.",
    "store.label": "Emplacement du magasin",
    "store.title": "Visitez notre boutique",
    "store.planPickup": "Planifier le retrait",
    "store.browseFirst": "Parcourir d'abord",

    // Shop page
    "shop.label": "Boutique",
    "shop.title": "Notre collection complète",
    "shop.subtitle": "Recherchez dans la collection, filtrez par catégorie et triez par prix.",
    "shop.searchPlaceholder": "Rechercher des produits...",
    "shop.allCategories": "Toutes les catégories",
    "shop.newest": "Plus récent",
    "shop.priceLow": "Prix croissant",
    "shop.priceHigh": "Prix décroissant",
    "shop.emptyTitle": "Aucun produit trouvé",
    "shop.emptyText": "Essayez une autre recherche ou catégorie.",
    "shop.page": "Page",
    "shop.of": "de",

    // Product
    "product.soldOut": "Épuisé",
    "product.from": "À partir de",
    "product.noOptions": "Pas d'options",
    "product.addToCart": "Ajouter au panier",
    "product.new": "NOUVEAU",
    "product.bestSeller": "BEST SELLER",
    "product.related": "Produits similaires",
    "product.relatedTitle": "Vous aimerez aussi",
    "product.inStock": "unités en stock",
    "product.outOfStock": "Rupture de stock",

    // Cart
    "cart.title": "Votre Panier",
    "cart.close": "Fermer le panier",
    "cart.empty": "Votre panier est vide",
    "cart.emptyHint": "Ajoutez un produit et il apparaîtra ici.",
    "cart.subtotal": "Sous-total",
    "cart.checkout": "Passer à la caisse",
    "cart.viewCart": "Voir le panier",

    // Footer
    "footer.description": "Parfums haut de gamme, soins du corps, huiles et produits de beauté sélectionnés pour leur profondeur, élégance et qualité.",
    "footer.visit": "Visite",
    "footer.follow": "Suivre",

    // Invoice
    "invoice.title": "Facture",
    "invoice.date": "Date",
    "invoice.orderNumber": "Commande N°",
    "invoice.billTo": "Facturer à",
    "invoice.deliveryMethod": "Mode de livraison",
    "invoice.homeDelivery": "Livraison à domicile",
    "invoice.storePickup": "Retrait en boutique",
    "invoice.item": "Article",
    "invoice.qty": "Qté",
    "invoice.unitPrice": "Prix unitaire",
    "invoice.total": "Total",
    "invoice.subtotal": "Sous-total",
    "invoice.deliveryFee": "Frais de livraison",
    "invoice.grandTotal": "Total Général",
    "invoice.print": "Imprimer la facture",
    "invoice.exportPdf": "Exporter en PDF",
    "invoice.thankYou": "Merci pour votre achat !",

    // Language
    "lang.en": "EN",
    "lang.fr": "FR"
  }
};

const LanguageContext = createContext<LanguageContextValue>({
  locale: "fr",
  setLocale: () => {},
  t: (key: string) => key
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("fr");

  useEffect(() => {
    const saved = localStorage.getItem("sary_lang") as Locale | null;
    if (saved && (saved === "en" || saved === "fr")) {
      setLocaleState(saved);
    }
  }, []);

  const setLocale = useCallback((newLocale: Locale) => {
    setLocaleState(newLocale);
    localStorage.setItem("sary_lang", newLocale);
    document.documentElement.lang = newLocale;
  }, []);

  const t = useCallback(
    (key: string) => {
      return translations[locale][key] || translations.en[key] || key;
    },
    [locale]
  );

  return (
    <LanguageContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
