"use client";

import { SessionProvider } from "next-auth/react";
import { CartProvider } from "@/components/providers/cart-provider";
import { LanguageProvider } from "@/components/providers/language-provider";

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <LanguageProvider>
        <CartProvider>{children}</CartProvider>
      </LanguageProvider>
    </SessionProvider>
  );
}
