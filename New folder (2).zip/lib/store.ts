export const storeConfig = {
  name: process.env.STORE_NAME || "Sary Parfume",
  address: process.env.STORE_ADDRESS || "Tunis, Tunisia",
  phone: process.env.STORE_PHONE || "+216 00 000 000",
  email: process.env.STORE_EMAIL || "contact@saryparfume.com",
  deliveryFee: Number(process.env.DELIVERY_FEE_TND || "7"),
  lat: 36.836005,
  lng: 10.107389
};
